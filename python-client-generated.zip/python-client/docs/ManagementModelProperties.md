# ManagementModelProperties

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**purposes** | **list[str]** |  | [optional] 
**model_class** | **str** |  | [optional] 
**vad_kind** | **str** |  | [optional] 
**uses_online_interpolation** | **bool** |  | [optional] 
**cascade_delete** | **bool** |  | [optional] 
**is_dynamic_grammar_supported** | **bool** |  | [optional] 
**uses_halide** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


