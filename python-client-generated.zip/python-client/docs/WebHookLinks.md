# WebHookLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ping** | **str** | The URL that can be used to trigger the sending of a ping event to the registered URL of a web hook registration. | [optional] 
**test** | **str** | The URL that can be used sending test events to the registered URL of a web hook registration. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


