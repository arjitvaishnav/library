# FileLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content_url** | **str** | The url to retrieve the content of this file. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


