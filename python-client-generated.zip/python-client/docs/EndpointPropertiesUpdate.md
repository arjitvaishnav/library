# EndpointPropertiesUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content_logging_enabled** | **bool** | A value indicating whether content logging (audio &amp;amp; transcriptions)  is being used for a deployment. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


